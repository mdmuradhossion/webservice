-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2021 at 11:05 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parsonal_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@gmail.com', NULL, '$2y$10$UFdPiZSLrlNIxdN0ywUVf.9Y0F9CIR3kVOZGPUnXAc6osH7Aii3OC', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `image`, `created_at`, `updated_at`) VALUES
(3, 'nazim', '1608746154client1.png', '2020-12-23 17:55:54', NULL),
(4, 'Dell-20 inc', '1608746720client2.png', '2020-12-23 18:05:20', NULL),
(5, 'admin', '1608746783flooop.png', '2020-12-23 18:06:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Web Design', 'web-design', '1', '2021-01-11 13:10:59', NULL),
(2, 'Development', 'development', '1', '2021-01-11 13:15:06', NULL),
(3, 'Joomla', 'joomla', '1', '2021-01-11 13:15:38', NULL),
(4, 'Wordpress', 'wordpress', '1', '2021-01-11 13:15:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chooseus`
--

CREATE TABLE `chooseus` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `title1` varchar(255) DEFAULT NULL,
  `title1des` varchar(255) DEFAULT NULL,
  `icon1` varchar(255) DEFAULT NULL,
  `title2` varchar(255) DEFAULT NULL,
  `title2des` varchar(255) DEFAULT NULL,
  `icon2` varchar(255) DEFAULT NULL,
  `title3` varchar(255) DEFAULT NULL,
  `title3des` varchar(255) DEFAULT NULL,
  `icon3` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chooseus`
--

INSERT INTO `chooseus` (`id`, `title`, `subtitle`, `description`, `title1`, `title1des`, `icon1`, `title2`, `title2des`, `icon2`, `title3`, `title3des`, `icon3`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Why Choose Us', 'KNOW MORE ABOUT OUR COMPANY', 'Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Proin gravida nibh vel velit auctor Aenean sollicitudin, adipisicing elit sed lorem quis bibendum auctor.', 'TONS OF FEATURES', 'Consectetur adipisicing elit sed do eiusmod tempor incididunt ut', '<i class=\"fa fa-bicycle\"></i>', 'POWERPACK THEME', 'Proin gravida nibh vel velit auctor Aenean sollicitudin adipisicing', '<i class=\"fa fa-diamond\"></i>', 'DAY NIGHT SUPPORT', 'Simply dummy text and typesettings industry has been the industry', '<i class=\"fa fa-street-view\"></i>', '1611934425image-block-bg.jpg', '2021-01-29 14:47:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `phone` varchar(155) NOT NULL,
  `email` varchar(155) NOT NULL,
  `address` text NOT NULL,
  `details` text DEFAULT NULL,
  `web` varchar(155) DEFAULT NULL,
  `map` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `phone`, `email`, `address`, `details`, `web`, `map`, `created_at`, `updated_at`) VALUES
(1, '+880 01631734128', 'muradhossion123@gmail.com', 'Nowapara,Ovainagor,Jessore', 'We are a awward winning multinational company. We believe in quality and standard worldwide.', 'dfgfdg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29094.71221640948!2d87.99184102070903!3d24.28235241107331!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fa2578eaf5484b%3A0xeeb431ddddc27e83!2sNowapara%20High%20School!5e0!3m2!1sen!2sbd!4v1610213975627!5m2!1sen!2sbd', '2021-01-09 05:48:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `code` varchar(155) NOT NULL,
  `symbol_left` varchar(155) NOT NULL,
  `symbol_right` varchar(155) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `title`, `code`, `symbol_left`, `symbol_right`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Bangladesh', 'BDT', '৳', '//=', '1', '2021-01-08 16:34:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `currency_record`
--

CREATE TABLE `currency_record` (
  `id` int(11) NOT NULL,
  `code` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `currency_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `currency_record`
--

INSERT INTO `currency_record` (`id`, `code`, `currency_name`) VALUES
(1, 'AED', 'United Arab Emirates Dirham'),
(2, 'AFN', 'Afghan Afghani'),
(3, 'ALL', 'Albanian Lek'),
(4, 'AMD', 'Armenian Dram'),
(5, 'ANG', 'Netherlands Antillean Guilder'),
(6, 'AOA', 'Angolan Kwanza'),
(7, 'ARS', 'Argentine Peso'),
(8, 'AUD', 'Australian Dollar'),
(9, 'AWG', 'Aruban Florin'),
(10, 'AZN', 'Azerbaijani Manat'),
(11, 'BAM', 'Bosnia-Herzegovina Convertible Mark'),
(12, 'BBD', 'Barbadian Dollar'),
(13, 'BDT', 'Bangladeshi Taka'),
(14, 'BGN', 'Bulgarian Lev'),
(15, 'BHD', 'Bahraini Dinar'),
(16, 'BIF', 'Burundian Franc'),
(17, 'BMD', 'Bermudan Dollar'),
(18, 'BND', 'Brunei Dollar'),
(19, 'BOB', 'Bolivian Boliviano'),
(20, 'BRL', 'Brazilian Real'),
(21, 'BSD', 'Bahamian Dollar'),
(22, 'BTC', 'Bitcoin'),
(23, 'BTN', 'Bhutanese Ngultrum'),
(24, 'BWP', 'Botswanan Pula'),
(25, 'BYN', 'Belarusian Ruble'),
(26, 'BZD', 'Belize Dollar'),
(27, 'CAD', 'Canadian Dollar'),
(28, 'CDF', 'Congolese Franc'),
(29, 'CHF', 'Swiss Franc'),
(30, 'CLF', 'Chilean Unit of Account (UF)'),
(31, 'CLP', 'Chilean Peso'),
(32, 'CNH', 'Chinese Yuan (Offshore)'),
(33, 'CNY', 'Chinese Yuan'),
(34, 'COP', 'Colombian Peso'),
(35, 'CRC', 'Costa Rican Colón'),
(36, 'CUC', 'Cuban Convertible Peso'),
(37, 'CUP', 'Cuban Peso'),
(38, 'CVE', 'Cape Verdean Escudo'),
(39, 'CZK', 'Czech Republic Koruna'),
(40, 'DJF', 'Djiboutian Franc'),
(41, 'DKK', 'Danish Krone'),
(42, 'DOP', 'Dominican Peso'),
(43, 'DZD', 'Algerian Dinar'),
(44, 'EGP', 'Egyptian Pound'),
(45, 'ERN', 'Eritrean Nakfa'),
(46, 'ETB', 'Ethiopian Birr'),
(47, 'EUR', 'Euro'),
(48, 'FJD', 'Fijian Dollar'),
(49, 'FKP', 'Falkland Islands Pound'),
(50, 'GBP', 'British Pound Sterling'),
(51, 'GEL', 'Georgian Lari'),
(52, 'GGP', 'Guernsey Pound'),
(53, 'GHS', 'Ghanaian Cedi'),
(54, 'GIP', 'Gibraltar Pound'),
(55, 'GMD', 'Gambian Dalasi'),
(56, 'GNF', 'Guinean Franc'),
(57, 'GTQ', 'Guatemalan Quetzal'),
(58, 'GYD', 'Guyanaese Dollar'),
(59, 'HKD', 'Hong Kong Dollar'),
(60, 'HNL', 'Honduran Lempira'),
(61, 'HRK', 'Croatian Kuna'),
(62, 'HTG', 'Haitian Gourde'),
(63, 'HUF', 'Hungarian Forint'),
(64, 'IDR', 'Indonesian Rupiah'),
(65, 'ILS', 'Israeli New Sheqel'),
(66, 'IMP', 'Manx pound'),
(67, 'INR', 'Indian Rupee'),
(68, 'IQD', 'Iraqi Dinar'),
(69, 'IRR', 'Iranian Rial'),
(70, 'ISK', 'Icelandic Króna'),
(71, 'JEP', 'Jersey Pound'),
(72, 'JMD', 'Jamaican Dollar'),
(73, 'JOD', 'Jordanian Dinar'),
(74, 'JPY', 'Japanese Yen'),
(75, 'KES', 'Kenyan Shilling'),
(76, 'KGS', 'Kyrgystani Som'),
(77, 'KHR', 'Cambodian Riel'),
(78, 'KMF', 'Comorian Franc'),
(79, 'KPW', 'North Korean Won'),
(80, 'KRW', 'South Korean Won'),
(81, 'KWD', 'Kuwaiti Dinar'),
(82, 'KYD', 'Cayman Islands Dollar'),
(83, 'KZT', 'Kazakhstani Tenge'),
(84, 'LAK', 'Laotian Kip'),
(85, 'LBP', 'Lebanese Pound'),
(86, 'LKR', 'Sri Lankan Rupee'),
(87, 'LRD', 'Liberian Dollar'),
(88, 'LSL', 'Lesotho Loti'),
(89, 'LYD', 'Libyan Dinar'),
(90, 'MAD', 'Moroccan Dirham'),
(91, 'MDL', 'Moldovan Leu'),
(92, 'MGA', 'Malagasy Ariary'),
(93, 'MKD', 'Macedonian Denar'),
(94, 'MMK', 'Myanma Kyat'),
(95, 'MNT', 'Mongolian Tugrik'),
(96, 'MOP', 'Macanese Pataca'),
(97, 'MRO', 'Mauritanian Ouguiya (pre-2018)'),
(98, 'MRU', 'Mauritanian Ouguiya'),
(99, 'MUR', 'Mauritian Rupee'),
(100, 'MVR', 'Maldivian Rufiyaa'),
(101, 'MWK', 'Malawian Kwacha'),
(102, 'MXN', 'Mexican Peso'),
(103, 'MYR', 'Malaysian Ringgit'),
(104, 'MZN', 'Mozambican Metical'),
(105, 'NAD', 'Namibian Dollar'),
(106, 'NGN', 'Nigerian Naira'),
(107, 'NIO', 'Nicaraguan Córdoba'),
(108, 'NOK', 'Norwegian Krone'),
(109, 'NPR', 'Nepalese Rupee'),
(110, 'NZD', 'New Zealand Dollar'),
(111, 'OMR', 'Omani Rial'),
(112, 'PAB', 'Panamanian Balboa'),
(113, 'PEN', 'Peruvian Nuevo Sol'),
(114, 'PGK', 'Papua New Guinean Kina'),
(115, 'PHP', 'Philippine Peso'),
(116, 'PKR', 'Pakistani Rupee'),
(117, 'PLN', 'Polish Zloty'),
(118, 'PYG', 'Paraguayan Guarani'),
(119, 'QAR', 'Qatari Rial'),
(120, 'RON', 'Romanian Leu'),
(121, 'RSD', 'Serbian Dinar'),
(122, 'RUB', 'Russian Ruble'),
(123, 'RWF', 'Rwandan Franc'),
(124, 'SAR', 'Saudi Riyal'),
(125, 'SBD', 'Solomon Islands Dollar'),
(126, 'SCR', 'Seychellois Rupee'),
(127, 'SDG', 'Sudanese Pound'),
(128, 'SEK', 'Swedish Krona'),
(129, 'SGD', 'Singapore Dollar'),
(130, 'SHP', 'Saint Helena Pound'),
(131, 'SLL', 'Sierra Leonean Leone'),
(132, 'SOS', 'Somali Shilling'),
(133, 'SRD', 'Surinamese Dollar'),
(134, 'SSP', 'South Sudanese Pound'),
(135, 'STD', 'São Tomé and Príncipe Dobra (pre-2018)'),
(136, 'STN', 'São Tomé and Príncipe Dobra'),
(137, 'SVC', 'Salvadoran Colón'),
(138, 'SYP', 'Syrian Pound'),
(139, 'SZL', 'Swazi Lilangeni'),
(140, 'THB', 'Thai Baht'),
(141, 'TJS', 'Tajikistani Somoni'),
(142, 'TMT', 'Turkmenistani Manat'),
(143, 'TND', 'Tunisian Dinar'),
(144, 'TOP', 'Tongan Pa\'anga'),
(145, 'TRY', 'Turkish Lira'),
(146, 'TTD', 'Trinidad and Tobago Dollar'),
(147, 'TWD', 'New Taiwan Dollar'),
(148, 'TZS', 'Tanzanian Shilling'),
(149, 'UAH', 'Ukrainian Hryvnia'),
(150, 'UGX', 'Ugandan Shilling'),
(151, 'USD', 'United States Dollar'),
(152, 'UYU', 'Uruguayan Peso'),
(153, 'UZS', 'Uzbekistan Som'),
(154, 'VEF', 'Venezuelan Bolívar Fuerte'),
(155, 'VND', 'Vietnamese Dong'),
(156, 'VUV', 'Vanuatu Vatu'),
(157, 'WST', 'Samoan Tala'),
(158, 'XAF', 'CFA Franc BEAC'),
(159, 'XAG', 'Silver Ounce'),
(160, 'XAU', 'Gold Ounce'),
(161, 'XCD', 'East Caribbean Dollar'),
(162, 'XDR', 'Special Drawing Rights'),
(163, 'XOF', 'CFA Franc BCEAO'),
(164, 'XPD', 'Palladium Ounce'),
(165, 'XPF', 'CFP Franc'),
(166, 'XPT', 'Platinum Ounce'),
(167, 'YER', 'Yemeni Rial'),
(168, 'ZAR', 'South African Rand'),
(169, 'ZMW', 'Zambian Kwacha'),
(170, 'ZWL', 'Zimbabwean Dollar');

-- --------------------------------------------------------

--
-- Table structure for table `footers`
--

CREATE TABLE `footers` (
  `id` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `is_twitter` enum('0','1') NOT NULL DEFAULT '0',
  `facebook` varchar(255) DEFAULT NULL,
  `is_facebook` enum('0','1') NOT NULL DEFAULT '0',
  `linkedin` varchar(255) DEFAULT NULL,
  `is_linkedin` enum('0','1') NOT NULL DEFAULT '0',
  `pinterest` varchar(255) DEFAULT NULL,
  `is_pinterest` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `footers`
--

INSERT INTO `footers` (`id`, `address`, `email`, `phone`, `description`, `twitter`, `is_twitter`, `facebook`, `is_facebook`, `linkedin`, `is_linkedin`, `pinterest`, `is_pinterest`, `created_at`, `updated_at`) VALUES
(1, 'Nowapara,Ovainagor,Jessore', 'muradhossion123@gmail.com', '01631734128', 'new personal web', 'https://twitter.com/', '1', 'https://facebook.com/', '1', 'https://linkedin.com/', '1', 'http://pinterest.com/', '1', '2020-12-31 02:25:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `generalsettings`
--

CREATE TABLE `generalsettings` (
  `id` int(11) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `sitetitle` varchar(255) DEFAULT NULL,
  `metatitel` varchar(255) DEFAULT NULL,
  `metadescription` text DEFAULT NULL,
  `metakeywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `metaauthor` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL,
  `slider_1` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `icon` varchar(255) NOT NULL,
  `icon_title` varchar(255) NOT NULL,
  `slider_2` varchar(255) DEFAULT NULL,
  `title2` varchar(255) NOT NULL,
  `text2` varchar(255) NOT NULL,
  `icon2` varchar(255) NOT NULL,
  `icon_title2` varchar(255) NOT NULL,
  `slider_3` varchar(255) DEFAULT NULL,
  `title3` varchar(255) NOT NULL,
  `text3` varchar(255) NOT NULL,
  `icon3` varchar(255) NOT NULL,
  `icon_title3` varchar(255) NOT NULL,
  `slider_4` varchar(255) DEFAULT NULL,
  `title4` varchar(255) NOT NULL,
  `text4` varchar(255) NOT NULL,
  `icon4` varchar(255) NOT NULL,
  `icon_title4` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `generalsettings`
--

INSERT INTO `generalsettings` (`id`, `logo`, `sitetitle`, `metatitel`, `metadescription`, `metakeywords`, `metaauthor`, `favicon`, `slider_1`, `title`, `text`, `icon`, `icon_title`, `slider_2`, `title2`, `text2`, `icon2`, `icon_title2`, `slider_3`, `title3`, `text3`, `icon3`, `icon_title3`, `slider_4`, `title4`, `text4`, `icon4`, `icon_title4`, `created_at`, `updated_at`) VALUES
(1, '1609812660client2.png', 'Service', 'Service', 'Service', 'Service', 'Service', '1610709832favicon.ico', '1609817011bg2.jpg', 'Need To Invent The Future!', 'We Making Difference To Great Things Possible', 'fa fa-bicycle', 'Invent', '1609817020bg3.jpg', 'How Big Can You Dream?', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. In consequatur cumque natus!', 'fa fa-hotel', 'Dream', '1609817028bg1.jpg', 'Your Challenge is Our Progress', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. In consequatur cumque natus!', 'fa fa-android', 'Tech', '1609817036bg3.jpg', 'WE ARE HERE TO MAKE IT HAPPEN', 'We Making Difference To Great Things Possible', 'fa fa-asterisk', 'Last', '2020-12-23 02:50:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ourgoals`
--

CREATE TABLE `ourgoals` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ourgoals`
--

INSERT INTO `ourgoals` (`id`, `title`, `description`, `icon`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Clean & Modern Design', 'Bras urna felis accumsan at ultrde cesid posuere masa socis nautoque penat', '<i class=\"fa fa-heart-o\"></i>', '1', '2021-02-26 15:39:07', NULL),
(2, 'USEFUL SHORTCODES', 'High Life narwhal, banh mi PBR single-origin coffee Odd Future actually aliqua', '<i class=\"fa fa-codepen\"></i>', '1', '2021-02-26 15:00:00', NULL),
(3, 'PARALLAX SECTION', 'Consectetur adipisicing elit sed do eiusmod tempor incididunt ut', '<i class=\"fa fa-film\"></i>', '1', '2021-02-26 15:08:54', NULL),
(4, 'Multipurpose Concept', 'Consectetur adipisicing elit sed do eiusmod tempor incididunt ut', '<i class=\"fa fa-newspaper-o\"></i>', '1', '2021-02-26 15:09:28', NULL),
(5, 'Responsive Layout', 'Consectetur adipisicing elit sed do eiusmod tempor incididunt ut', '<i class=\"fa fa-desktop\"></i>', '1', '2021-02-26 15:09:55', NULL),
(6, 'Light wight Performance', 'High Life narwhal, banh mi PBR single-origin coffee Odd Future actually aliqua', '<i class=\"fa fa-pagelines\"></i>', '1', '2021-02-26 15:13:00', NULL),
(7, 'Free Lifetime Updates', 'Bras urna felis accumsan at ultrde cesid posuere masa socis nautoque penat', '<i class=\"fa fa-recycle\"></i>', '1', '2021-02-26 15:13:38', NULL),
(8, 'Endless Possibilites', 'High Life narwhal, banh mi PBR single-origin coffee Odd Future actually aliqua', '<i class=\"fa fa-diamond\"></i>', '1', '2021-02-26 15:14:05', NULL),
(9, '24/7 Live Support', 'Consectetur adipisicing elit sed do eiusmod tempor incididunt ut', '<i class=\"fa fa-whatsapp\"></i>', '1', '2021-02-26 15:53:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ourteams`
--

CREATE TABLE `ourteams` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `icon` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `portfolios`
--

CREATE TABLE `portfolios` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `technology` varchar(255) DEFAULT NULL,
  `link` varchar(155) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `full_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `portfolios`
--

INSERT INTO `portfolios` (`id`, `slug`, `name`, `description`, `technology`, `link`, `image`, `full_image`, `created_at`, `updated_at`) VALUES
(1, 'web-design', 'test', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Laravel', NULL, '1609000032download.jpg', '1608820863bg1.jpg', '2020-12-24 14:41:03', NULL),
(2, 'wordpress', 'safasfs', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'afasfas', NULL, '1609001177download.jpg', '1609001177bg1.jpg', '2020-12-26 16:46:17', NULL),
(3, 'development', 'MD Murad', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Laravel', NULL, '1609437212download.jpg', '1609437212bg1.jpg', '2020-12-31 17:53:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `prices`
--

CREATE TABLE `prices` (
  `id` int(11) NOT NULL,
  `ser_item_id` int(11) DEFAULT NULL,
  `basic` int(11) NOT NULL,
  `standard` int(11) NOT NULL,
  `professional` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prices`
--

INSERT INTO `prices` (`id`, `ser_item_id`, `basic`, `standard`, `professional`, `created_at`, `updated_at`) VALUES
(2, 2, 20, 30, 50, '2021-01-08 05:14:32', NULL),
(3, 3, 20, 30, 50, '2021-01-08 11:11:31', NULL),
(4, 3, 20, 60, 70, '2021-01-29 11:35:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `icon`, `description`, `created_at`, `updated_at`) VALUES
(1, 'WEB DESIGN', 'fa fa-tachometer', 'High Life narwhal, banh mi PBR single-origin coffee Odd Future actually aliqua polaroid befor', '2021-01-02 17:54:09', NULL),
(2, 'APPS DEVELOPMENT', 'fa fa-android', 'Food truck master cleanse mixtape minim Portland, cardigan stumptown chambray swag', '2021-01-02 17:55:14', NULL),
(3, 'ECOMMERCE WEBSITES', 'fa fa-shopping-cart', 'Neutra Thundercats craft beer, listicle meggings bicycle rights 90\'s XOXO beard cardiga', '2021-01-02 17:56:09', NULL),
(4, 'DESIGN FOR STARTUPS', 'fa fa-lightbulb-o', 'We design beautiful modern engaging websites that always latest responsive technologies.', '2021-01-02 17:56:56', NULL),
(5, 'test', 'fa fa-lightbulb-o', 'sfasfasfs', '2021-01-05 02:40:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `servicesitems`
--

CREATE TABLE `servicesitems` (
  `id` int(11) NOT NULL,
  `ser_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `image1` varchar(255) DEFAULT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `image3` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `servicesitems`
--

INSERT INTO `servicesitems` (`id`, `ser_id`, `item_name`, `image`, `image1`, `image2`, `image3`, `created_at`, `updated_at`) VALUES
(1, 1, 'Website PSD Design', '1609812197img (1).jpg', '1609727814img (2).jpg', '1609727814img (3).jpg', '1609727814img (4).jpg', '2021-01-04 02:36:54', NULL),
(2, 1, 'Responsive Template Design', '1609813014img (3).jpg', '1609813014img (4).jpg', '1609813014img (2).jpg', '1609813014img (1).jpg', '2021-01-05 02:16:54', NULL),
(3, 1, 'Email Template PSD Design', '1609813710img (2).jpg', '1609813710img (3).jpg', '1609813710img (1).jpg', '1609813710img (4).jpg', '2021-01-05 02:28:30', NULL),
(4, 2, 'Mobile app', '1609815495img (4).jpg', '1609815495img (3).jpg', '1609815495img (2).jpg', '1609815495img (1).jpg', '2021-01-05 02:58:15', NULL),
(5, 3, 'Open Cart', '1609815525img (2).jpg', '1609815525img (4).jpg', '1609815525img (1).jpg', '1609815525img (3).jpg', '2021-01-05 02:58:45', NULL),
(6, 4, 'Responsive Website', '1609815560img (1).jpg', '1609815560img (2).jpg', '1609815560img (3).jpg', '1609815560img (4).jpg', '2021-01-05 02:59:20', NULL),
(7, 3, 'Joomla', '1609815602img (2).jpg', '1609815602img (3).jpg', '1609815602img (4).jpg', '1609815602img (1).jpg', '2021-01-05 03:00:02', NULL),
(8, 2, 'Android Apps', '1609815639img (1).jpg', '1609815639img (3).jpg', '1609815639img (2).jpg', '1609815639img (4).jpg', '2021-01-05 03:00:39', NULL),
(9, 2, 'Windows Applications', '1609815665img (3).jpg', '1609815665img (2).jpg', '1609815665img (1).jpg', '1609815665img (4).jpg', '2021-01-05 03:01:05', NULL),
(10, 4, 'Custom CMS', '1609815731img (2).jpg', '1609815731img (4).jpg', '1609815731img (3).jpg', '1609815731img (1).jpg', '2021-01-05 03:02:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@demo.com', NULL, '$2y$10$UFdPiZSLrlNIxdN0ywUVf.9Y0F9CIR3kVOZGPUnXAc6osH7Aii3OC', NULL, '2020-12-11 06:52:35', '2020-12-11 06:52:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chooseus`
--
ALTER TABLE `chooseus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `currency_record`
--
ALTER TABLE `currency_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footers`
--
ALTER TABLE `footers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generalsettings`
--
ALTER TABLE `generalsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ourgoals`
--
ALTER TABLE `ourgoals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ourteams`
--
ALTER TABLE `ourteams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolios`
--
ALTER TABLE `portfolios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_id` (`slug`);

--
-- Indexes for table `prices`
--
ALTER TABLE `prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `servicesitems`
--
ALTER TABLE `servicesitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `chooseus`
--
ALTER TABLE `chooseus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `currency_record`
--
ALTER TABLE `currency_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT for table `footers`
--
ALTER TABLE `footers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `generalsettings`
--
ALTER TABLE `generalsettings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ourgoals`
--
ALTER TABLE `ourgoals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `ourteams`
--
ALTER TABLE `ourteams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `portfolios`
--
ALTER TABLE `portfolios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `prices`
--
ALTER TABLE `prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `servicesitems`
--
ALTER TABLE `servicesitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
